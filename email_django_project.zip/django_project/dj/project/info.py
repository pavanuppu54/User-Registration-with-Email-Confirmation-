EMAIL_USE_TLS =True
EMAIL_HOST='smtp.gmail.com'
EMAIL_HOST_USER='ramya9652414628@gmail.com'
EMAIL_HOST_PASSWORD='apkm sfru abfu fyvf'
EMAIL_PORT=587